module Demo exposing (..)

import Http exposing(..)
import Html exposing(text, div)
import Json.Decode as Decode exposing (..)
import RemoteData exposing (WebData)

type JsonValue
    = JString String
    | JInt Int
    | JNull
    | JList (List JsonValue)
    | JObj (List (String, JsonValue))
    | JIn (List (Int, JsonValue))

type Msg
    = PostsReceived (WebData (JsonValue))

type alias Model =
    { posts : WebData (JsonValue)
    }

jsonDecoder : Decoder JsonValue
jsonDecoder =
    oneOf
        [ map JString string
        , null JNull
        , map JList <| list <| lazy (\_ -> jsonDecoder)
        , map JObj <| keyValuePairs <| lazy (\_ -> jsonDecoder)
        ]

sample = """
[
        {
            "413552": ":send[95m09:34:54.787 FCG_MOVE_START_SYN %{x: 42825.01913265306, y: -13706.938775510203, z: -7166.59619140625}[0m",
            "414178": "%{_op: :FCG_MOVE_START_SYN, msg: %{angle: 18.123214283049176, clientState: 1, curPos: %{x: 51809.66015625, y: -10718.7900390625, z: -8180.1396484375}, direction: %{x: -1331.6004614796611, y: 435.83135436312705, z: 0.0}, isSend: 1, mapIndex: 101, moveState: Run, moveType: Ground, serverRandom: 0}}",
            "414547": "[\"\\e[33m\", \"1654681027386 sending_move %{x: 22744.52324404984, y: -12879.911166686714, z: -8478.466796875} 27405\"]",
            "413514": "%{_op: :FCG_MOVE_START_SYN, msg: %{angle: -122.36280016297475, clientState:1, curPos: %{x: 44731.953125, y: -10697.7744140625, z: -7707.53271484375}, direction: %{x: -749.5370673833246, y: -1182.7781385192711, z: 0.0}, isSend: 1, mapIndex: 101, moveState: Run, moveType: Ground, serverRandom: 0}}",
            "414026": ":send[95m09:35:51.501 :FCG_ATTACK_SKILL_SHOOT_SYN 8010[0m",
            "415251": "[\"\\e[33m\", \"1654681168019 sending_move %{x: 53984.7911421604, y: -20792.211254670394, z: -8667.177734375} 56453\"]",
            "414754": "[\"\\e[38;5;100m\", \"-> {:execute_node, [$gamestate, %{_node: Node.QuestTalkNpc, choice: 0, serial: 948}]}\", \"\\e[0m\"]",
            "411811": "[level: :info, uuid: \"wXefm4cRGSN\", msg: \"AttackOne 135939560 need to walk 1254\"]",
            "413781": ":recv[32m09:35:27.083 FCG_ATTACK_HIT_DAMAGE_CMD[0m",
            "411741": ":recv[32m09:30:56.174 FCG_ATTACK_DEAD_CMD 135936569 50007[0m",
            "416590": "an actual confirmation, lets grab z: 0.0 %{x: 1339.337939258994, y: 407.96231267056027, z: 0.0}",
            "414468": "an actual confirmation, lets grab z: 0.0 %{x: -1397.1305058624382, y: 90.09077606110475, z: 0.0}",
            "413598": ":send[95m09:35:04.880 FCG_MOVE_START_SYN %{x: 44828.06769563604, y: -13015.7118616861, z: -8829.78955078125}[0m",
            "413095": ":recv[32m09:33:14.631 FCG_ATTACK_DEAD_CMD 135973050 50022[0m",
            "412782": ":recv[32m09:32:47.790 FCG_ATTACK_SKILL_SERIAL_CMD[0m",
            "416306": ":recv[32m09:41:20.447 mob skillshot: 50072 50072010 %{x: 55155, y: -19092, z: -8668} curHp: 105 nil[0m",
            "412496": ":recv[32m09:32:20.342 FCG_ATTACK_SKILL_SERIAL_CMD[0m",
            "415985": ":recv[32m09:40:46.632 FCG_ATTACK_HIT_DAMAGE_CMD[0m",}
            ]
"""

fetchPosts : Cmd Msg
fetchPosts =
    Http.get
        { url = "http://localhost:5020/posts"
        , expect =
            jsonDecoder
                |> Http.expectJson (RemoteData.fromResult >> PostsReceived)
        }

main =
    case decodeString jsonDecoder sample  of
        Err err -> 
            div [] [ text <| errorToString err ]

        Ok tree ->        
            div [] 
                [ text <| Debug.toString tree
                ]
