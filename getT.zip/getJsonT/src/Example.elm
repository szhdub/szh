module Example exposing (..)

import Html exposing (..)
import Browser exposing (..)

type Model
    = DisplayingRoom DoorState AlarmState
    | Failure String


type DoorState
    = Opened
    | Closed
    | Locked


type AlarmState
    = Armed
    | Disarmed
    | Triggered


type Msg
    = Open
    | Close
    | Lock
    | Unlock
    | Arm
    | Disarm


update : Msg -> Model -> Model
update msg model =
    case model of
        DisplayingRoom doorState alarmState ->
            case doorState of
                Opened ->
                    case msg of
                        Close ->
                            DisplayingRoom Closed alarmState

                        _ ->
                            Failure "故障，观测不到！"

                Closed ->
                    case msg of
                        Open ->
                            case alarmState of
                                Armed ->
                                    DisplayingRoom Opened Triggered

                                _ ->
                                    DisplayingRoom Opened alarmState

                        Lock ->
                            DisplayingRoom Locked alarmState

                        Arm ->
                            DisplayingRoom Closed Armed

                        Disarm ->
                            DisplayingRoom Closed Disarmed

                        _ ->
                            Failure "故障，观测不到！"

                Locked ->
                    case msg of
                        Unlock ->
                            DisplayingRoom Closed alarmState

                        Arm ->
                            DisplayingRoom Locked Armed

                        Disarm ->
                            DisplayingRoom Locked Disarmed

                        _ ->
                            Failure "故障，观测不到！"
        Failure _ ->
            model

view : Model -> Html Msg
view model =
  case model of
        Failure message ->
            div [][
                p [] [ text "故障，观测不到！" ] ]
        DisplayingRoom doorState alarmState ->
            div []
                [ div [] [ 
                    case doorState of
                    Opened ->
                        div []
                            [ p [] [ text "门开-> 关门！" ] ]
                    Closed ->
                        div []
                            [ p [] [ text "门关-> 开门！" ] ]
                    Locked ->
                        div []
                            [ p [] [ text "门锁-> 开锁！" ] ]
                ],
                    div []
                        [ case alarmState of
                                Armed ->
                                    div []
                                        [ p [] [ text "毒药陷阱被触发-> 开门！" ] ]
                                disArmed ->
                                    div []
                                        [ p [] [ text "毒药陷阱没有触发-> 毒药陷阱被触发！" ] ]
                                -- Triggered ->
                                --     div []
                                --         [ p [] [ text "拔掉保险丝-> 毒药陷阱被触发/毒药陷阱没有触发！" ] ]
                    ]
                ]
            
initialModel : Model
initialModel = DisplayingRoom Closed Triggered

main : Program () Model Msg
main = Browser.sandbox
    { init = initialModel
    , view = view
    , update = update
    }