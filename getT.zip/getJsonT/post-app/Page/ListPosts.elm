module Page.ListPosts exposing (Model, Msg, init, update, view)

import Html exposing (..)
import Html.Attributes exposing (..)
import Html.Events exposing (onClick, onInput)
import Http
import Post exposing (Post, listJsonDecoder, listPostDecoder)
import RemoteData exposing (WebData)
import Url.Parser exposing (query)


type alias Model =
    { posts : WebData (List Post)
    , query : String
    }


type Msg
    = FetchPosts
    | PostsReceived (WebData (List Post))
    -- | FilterPosts
    | Text String
    | NonePost


init : ( Model, Cmd Msg )
init =
    ( { posts = RemoteData.NotAsked
      , query = ""
      }
    , Cmd.none
    )


fetchPosts : Cmd Msg
fetchPosts =
    Http.get
        { url = "http://localhost:5020/servers"
        , expect =
            listPostDecoder
                |> Http.expectJson (RemoteData.fromResult >> PostsReceived)
        }


update : Msg -> Model -> ( Model, Cmd Msg )
update msg model =
    case msg of
        FetchPosts ->
            ( { model | posts = RemoteData.Loading }, fetchPosts )

        -- FilterPosts ->
        --     ({ model | posts = (List.filter (String.contains model.query Post.count )) }, Cmd.none)

        PostsReceived response ->
            ( { model | posts = response }, Cmd.none )

        Text query ->
            ( { model | query = query }, Cmd.none )

        NonePost ->
            ( model, Cmd.none )


view : Model -> Html Msg
view model =
    div []
        [ div [ style "height" "88%"
        , style "width" "40%"
        , style "border" "3px solid #266627"
        , style "position" "absolute"
        , style "top" "5%"
        , style "left" "2.5%"
        , style "border-radius" "6px"
        , style "overflow-y" "scroll" 
        ] [ viewPosts model.posts ] 
        , viewInput model.query
        ]


viewInput : String -> Html Msg
viewInput query =
    div
        [ style "position" "absolute"
        , style "top" "50px"
        , style "left" "1100px"
        , style "width" "500px"
        , style "border-radius" "6px"
        ]
        [ input
            [ placeholder "这里输入数据"
            , onInput Text
            , style "width" "350px"
            , style "height" "25px"
            , style "margin" "8px"
            , style "border-radius" "6px"
            ]
            []
        , button
            [ onClick
                (if query == "" then
                    NonePost

                 else
                    FetchPosts
                )
            , style "background-color" "white"
            , style "color" "black"
            , style "border" "2px solid #e7e7e7"
            , style "border-radius" "6px"
            , style "width" "40px"
            , style "height" "30px"
            , style "cursor" "pointer" 
            ]
            [ text "提交" ]
        ]


viewPosts : WebData (List Post) -> Html Msg
viewPosts posts =
    case posts of
        RemoteData.NotAsked ->
            div
                [ style "margin" "10px"
                , style "font-size" "18px"
                , style "font-weight" "bold"
                ]
                [ text "等待加载数据～" ]

        RemoteData.Loading ->
            h3 [ style "margin" "10px" , style "color" "yellow" ] [ text "加载中..." ]

        RemoteData.Success actualPosts ->
            div[]
                [ div [ style "margin" "10px" ]
                    (List.map viewPost actualPosts)
                ]

        RemoteData.Failure httpError ->
            viewFetchError (buildErrorMessage httpError)


viewPost : Post -> Html msg
viewPost value =
    table []
        [ td []
            [ text (String.fromInt value.count) ]
        , td []
            [ text (String.fromInt value.connecting_lobby) ]
        , td []
            [ text (String.fromInt value.ingame) ]
        ]


viewFetchError : String -> Html Msg
viewFetchError errorMessage =
    let
        errorHeading =
            "现在不能获取数据."
    in
    div []
        [ h3 [] [ text errorHeading ]
        , text ("错误: " ++ errorMessage)
        ]


buildErrorMessage : Http.Error -> String
buildErrorMessage httpError =
    case httpError of
        Http.BadUrl message ->
            message

        Http.Timeout ->
            "服务器相应超时，过会儿再试吧."

        Http.NetworkError ->
            "无法访问服务器。"

        Http.BadStatus statusCode ->
            "请求失败！状态码是: " ++ String.fromInt statusCode

        Http.BadBody message ->
            message
