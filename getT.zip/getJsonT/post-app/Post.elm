module Post exposing (Post, JsonValue, listJsonDecoder, listPostDecoder)

import Json.Decode as Decode exposing (Decoder, list, int)
import Json.Decode.Pipeline exposing (required, optionalAt)


type alias Post =
    { count : Int 
    , connecting_lobby : Int
    , ingame : Int
    }


type JsonValue
    = JString String
    | JFloat Float
    | JList (List JsonValue)
    | JObj (List ( String, JsonValue ))


jsonDecoder : Decode.Decoder JsonValue
jsonDecoder =
    Decode.oneOf
        [ Decode.map JString Decode.string
        , Decode.map JFloat Decode.float
        , Decode.map JList <| Decode.list <| Decode.lazy (\_ -> jsonDecoder)
        , Decode.map JObj <| Decode.keyValuePairs <| Decode.lazy (\_ -> jsonDecoder)
        ]

listJsonDecoder : Decoder (List JsonValue)
listJsonDecoder =
    list jsonDecoder

listPostDecoder : Decoder (List Post)
listPostDecoder =
    list postDecoder

postDecoder : Decode.Decoder Post
postDecoder =
    Decode.succeed Post
        |> required "count" int
        |> optionalAt ["states","connecting_lobby"] int 0
        |> optionalAt ["states", "ingame"] int 0